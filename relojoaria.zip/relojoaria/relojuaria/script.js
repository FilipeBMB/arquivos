const cartCount = document.querySelector('.cart-count');
let itemCount = 0;

cartCount.textContent = itemCount;

function addItemToCart() {
  itemCount++;
  cartCount.textContent = itemCount;
}



document.addEventListener("DOMContentLoaded", function () {
  const questionForm = document.getElementById("question-form");
  const responseMessage = document.getElementById("response-message");

  questionForm.addEventListener("submit", function (event) {
    event.preventDefault();

    
    setTimeout(function () {
      responseMessage.textContent =
        "Obrigado por enviar suas perguntas! Iremos analisá-las e retornaremos em breve.";
    }, 1500);

    questionForm.reset();
  });
});

 function exibirMensagem() {
      document.getElementById("formulario").style.display = "none";
      document.getElementById("mensagem").style.display = "block";
      return false;
    }
    

    